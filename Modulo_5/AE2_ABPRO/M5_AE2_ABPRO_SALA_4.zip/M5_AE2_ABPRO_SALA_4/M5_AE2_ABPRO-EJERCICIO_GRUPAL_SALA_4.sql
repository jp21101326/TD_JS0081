/*
•	 CREACIÓN DE TABLAS
*/
	CREATE TABLE Clientes (
	    id_cliente INT PRIMARY KEY,
	    nombre     VARCHAR NOT NULL,
	    telefono   VARCHAR NOT NULL,
	    email      VARCHAR NOT NULL,
	    direccion  VARCHAR NOT NULL
	);

	CREATE TABLE Vehiculos (
	    id_vehiculo INT PRIMARY KEY,
	    marca       VARCHAR NOT NULL,
	    modelo      VARCHAR NOT NULL,
	    anio        INT     NOT NULL,
	    precio_dia  REAL    NOT NULL
	);

	CREATE TABLE Alquileres (
	    id_alquiler  INT PRIMARY KEY,
	    id_cliente   INT,
	    id_vehiculo  INT,
	    fecha_inicio DATE,
	    fecha_fin    DATE,
	    FOREIGN KEY (id_cliente)  REFERENCES Clientes(id_cliente),
	    FOREIGN KEY (id_vehiculo) REFERENCES Vehiculos(id_vehiculo)
	);

	CREATE TABLE Pagos (
	    id_pago     INT PRIMARY KEY,
	    id_alquiler INT,
	    monto       REAL,
	    fecha_pago  DATE,
	    FOREIGN KEY (id_alquiler) REFERENCES Alquileres(id_alquiler)
	);


/*
•	INSERCIÓN DE REGISTROS
*/
	INSERT INTO Clientes VALUES
	(1, 'Juan Pérez', '555-1234', 'juan@mail.com', 'Calle 123'),
	(2, 'Laura Gómez', '555-5678', 'laura@mail.com', 'Calle 456'),
	(3, 'Carlos Sánchez', '555-9101', 'carlos@mail.com', 'Calle 789');


	INSERT INTO Vehiculos VALUES
	(1, 'Toyota', 'Corolla', 2020, 30.00),
	(2, 'Honda', 'Civic', 2019, 28.00),
	(3, 'Ford', 'Focus', 2021, 35.00);

	INSERT INTO Alquileres VALUES
	(1, 1, 2, '2025-03-10', '2025-03-15'),
	(2, 2, 1, '2025-03-12', '2025-03-16'),
	(3, 3, 3, '2025-03-20', '2025-03-22');

	INSERT INTO Pagos VALUES
	(1, 1, 150.00, '2025-03-12'),
	(2, 2, 112.00, '2025-03-13'),
	(3, 3, 70.00, '2025-03-20');

	-- select * from Clientes;
	-- select * from Vehiculos;
	-- select * from Alquileres;
	-- select * from Pagos;
	
	
/*
•	CONSULTAS REQUERIDAS
*/
/*
•	Consulta 1: Mostrar el nombre, telefono y email de todos los clientes que tienen un alquiler
    activo (es decir, cuya fecha actual esté dentro del rango entre fecha_inicio y fecha_fin).
*/
	/* select  date('now')  --> 2025-08-22 */
	SELECT c.nombre, c.telefono, c.email
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	WHERE date('now') BETWEEN a.fecha_inicio AND a.fecha_fin;

    /* OTRA FORMA */
    /* select CURRENT_DATE --> 2025-08-22 */
	SELECT c.nombre, c.telefono, c.email
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	WHERE CURRENT_DATE BETWEEN a.fecha_inicio AND a.fecha_fin;

/*
•   Consulta 2: Mostrar los vehículos que se alquilaron en el mes de marzo de 2025. Debe mostrar el modelo,
    marca, y precio_dia de esos vehículos. 
--  SELECT * FROM Alquileres
*/
	SELECT v.modelo, v.marca, v.precio_dia
	FROM Vehiculos v
	JOIN Alquileres a ON v.id_vehiculo = a.id_vehiculo
	WHERE EXTRACT(MONTH FROM a.fecha_inicio) = 3
	  AND EXTRACT(YEAR FROM a.fecha_inicio) = 2025;

/* 
•	Consulta 3: Calcular el precio total del alquiler para cada cliente, considerando el número de días
    que alquiló el vehículo (el precio por día de cada vehículo multiplicado por la cantidad de días de alquiler).
 -- SELECT * FROM pagos
*/
	SELECT c.nombre, 
	       SUM((a.fecha_fin - a.fecha_inicio + 1) * v.precio_dia) AS total_alquiler
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	JOIN Vehiculos v ON a.id_vehiculo = v.id_vehiculo
	GROUP BY c.nombre;

/*
•	Consulta 4: Encontrar los clientes que no han realizado ningún pago (no tienen registros en la tabla Pagos).
    Muestra su nombre y email.
*/
	SELECT c.nombre, c.email
	FROM Clientes c
	LEFT JOIN Alquileres a ON c.id_cliente = a.id_cliente
	LEFT JOIN Pagos p ON a.id_alquiler = p.id_alquiler
	WHERE p.id_pago IS NULL;

/*
•	Consulta 5: Calcular el promedio de los pagos realizados por cada cliente. Muestra el nombre del cliente
    y el promedio de pago.
*/
	SELECT c.nombre, AVG(p.monto) AS promedio_pago
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	JOIN Pagos p ON a.id_alquiler = p.id_alquiler
	GROUP BY c.nombre;

/*
•	Consulta 6: Mostrar los vehículos que están disponibles para alquilar en una fecha específica
    (por ejemplo, 2025-03-18). Debe mostrar el modelo, marca y precio_dia.  Si el vehículo está ocupado,
    no se debe incluir.
*/
	SELECT v.modelo, v.marca, v.precio_dia
	FROM Vehiculos v
	WHERE v.id_vehiculo NOT IN (
	    SELECT a.id_vehiculo
	    FROM Alquileres a
	    WHERE DATE '2025-03-18' BETWEEN a.fecha_inicio AND a.fecha_fin
	);


/*
•	Consulta 7: Encontrar la marca y el modelo de los vehículos que se alquilaron más de una vez en el mes
    de marzo de 2025.
*/
	SELECT v.marca, v.modelo, COUNT(*) AS veces_alquilado
	FROM Vehiculos v
	JOIN Alquileres a ON v.id_vehiculo = a.id_vehiculo
	WHERE EXTRACT(YEAR FROM a.fecha_inicio) = 2025
	    AND EXTRACT(MONTH FROM a.fecha_inicio) = 3
	GROUP BY v.marca, v.modelo
	HAVING COUNT(*) > 1;

/*
•	Consulta 8: Mostrar el total de monto pagado por cada cliente. Debe mostrar el nombre del cliente
    y la cantidad total de pagos realizados (suma del monto de los pagos).
*/
	SELECT c.nombre, SUM(p.monto) AS total_pagado
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	JOIN Pagos p ON a.id_alquiler = p.id_alquiler
	GROUP BY c.nombre;

/*
•	Consulta 9: Mostrar los clientes que alquilaron el vehículo Ford Focus (con id_vehiculo = 3). 
    Debe mostrar el nombre del cliente y la fecha del alquiler
*/
	SELECT c.nombre, a.fecha_inicio, a.fecha_fin
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	WHERE a.id_vehiculo = 3;

/*
•	Consulta 10: Realizar una consulta que muestre el nombre del cliente y el total de días alquilados
    de cada cliente, ordenado de mayor a menor total de días. El total de días es calculado como la
    diferencia entre fecha_inicio y fecha_fin.
*/
	SELECT c.nombre,
	            SUM((a.fecha_fin - a.fecha_inicio + 1)) AS total_dias
	FROM Clientes c
	JOIN Alquileres a ON c.id_cliente = a.id_cliente
	GROUP BY c.nombre
	ORDER BY total_dias DESC;


